--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Do not attempt to drop or recreate the postgres database in your actual dump!
-- DROP DATABASE postgres;

-- CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';
-- ALTER DATABASE postgres OWNER TO postgres;

-- \connect postgres

--
-- Data for Name: CH; Type: TABLE DATA; Schema: public; Owner: webuser1
--

COPY public."CH" ("Prefix", "Number", "Title", "GU", "CH", "Frequency", "Active", "Description", "Remarks") FROM stdin;
\.
COPY public."CH" ("Prefix", "Number", "Title", "GU", "CH", "Frequency", "Active", "Description", "Remarks") FROM '/var/lib/postgresql/14/main/3368.dat';

--
-- Data for Name: Department Committee Assignments; Type: TABLE DATA; Schema: public; Owner: webuser1
--

COPY public."Department Committee Assignments" ("faculty_ID", "committee_ID", "start_date", "end_date", "remarks") FROM stdin;
\.
COPY public."Department Committee Assignments" ("faculty_ID", "committee_ID", "start_date", "end_date", "remarks") FROM '/var/lib/postgresql/14/main/3363.dat';

--
-- Data for Name: Department Committee Names; Type: TABLE DATA; Schema: public; Owner: webuser1
--

COPY public."Department Committee Names" ("ID", "committee_name", "remarks") FROM stdin;
\.
COPY public."Department Committee Names" ("ID", "committee_name", "remarks") FROM '/var/lib/postgresql/14/main/3364.dat';

--
-- Data for Name: Department Course Directors; Type: TABLE DATA; Schema: public; Owner: webuser1
--

COPY public."Department Course Directors" ("Prefix", "Number", "CourseDirectorID", "Remarks") FROM stdin;
\.
COPY public."Department Course Directors" ("Prefix", "Number", "CourseDirectorID", "Remarks") FROM '/var/lib/postgresql/14/main/3365.dat';

--
-- Data for Name: Faculty; Type: TABLE DATA; Schema: public; Owner: webuser1
--

COPY public."Faculty" ("ID", "Honorific", "First", "MI", "Last", "Email", "Phone", "Office", "Research", "Rank", "Remarks", "CurrentlyEmployed") FROM stdin;
\.
COPY public."Faculty" ("ID", "Honorific", "First", "MI", "Last", "Email", "Phone", "Office", "Research", "Rank", "Remarks", "CurrentlyEmployed") FROM '/var/lib/postgresql/14/main/3362.dat';

--
-- Data for Name: Prerequisites; Type: TABLE DATA; Schema: public; Owner: webuser1
--

COPY public."Prerequisites" ("Prefix", "Number", "PC-prefix", "PC-number", "PC-code") FROM stdin;
\.
COPY public."Prerequisites" ("Prefix", "Number", "PC-prefix", "PC-number", "PC-code") FROM '/var/lib/postgresql/14/main/3367.dat';

--
-- Data for Name: Schedule History; Type: TABLE DATA; Schema: public; Owner: webuser1
--

COPY public."Schedule History" ("Year", "Semester", "Prefix", "Number", "Section", "CRN", "Enrollment", "Instructor", "Days", "BeginTime", "EndTime", "Remarks") FROM stdin;
\.
COPY public."Schedule History" ("Year", "Semester", "Prefix", "Number", "Section", "CRN", "Enrollment", "Instructor", "Days", "BeginTime", "EndTime", "Remarks") FROM '/var/lib/postgresql/14/main/3366.dat';

--
-- PostgreSQL database dump complete
--


